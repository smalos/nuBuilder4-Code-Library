/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `trumbowyg_sample` (
  `trumbowyg_sample_id` varchar(25) NOT NULL,
  `cus_firstname` varchar(1000) DEFAULT NULL,
  `cus_lastname` varchar(1000) DEFAULT NULL,
  `cus_notes` text,
  PRIMARY KEY (`trumbowyg_sample_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `trumbowyg_sample` DISABLE KEYS */;
INSERT INTO `trumbowyg_sample` VALUES ('5ec179d39fc1fa4','nu','Builder','<p style=\"background-color: rgb(255, 255, 255); margin-bottom: 16px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; color: rgb(36, 41, 46);\"><b>About nuBuilder</b></p><p style=\"background-color: rgb(255, 255, 255); margin-bottom: 16px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; color: rgb(36, 41, 46);\">nuBuilder is a browser-based tool for developing web-based database applications. It is written in PHP/SQL/Javascript/jQuery.</p><p style=\"background-color: rgb(255, 255, 255); margin-bottom: 16px; font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; color: rgb(36, 41, 46);\"><span style=\"font-weight: 600;\">Features:</span></p><ul style=\"padding-left: 2em; background-color: rgb(255, 255, 255); font-family: -apple-system, BlinkMacSystemFont, &quot;Segoe UI&quot;, Helvetica, Arial, sans-serif, &quot;Apple Color Emoji&quot;, &quot;Segoe UI Emoji&quot;; font-size: 16px; color: rgb(36, 41, 46); margin-bottom: 0px !important;\"><li>low-code</li><li style=\"margin-top: 0.25em;\">SQL Builder</li><li style=\"margin-top: 0.25em;\">Form Builder</li><li style=\"margin-top: 0.25em;\">Report Builder</li><li style=\"margin-top: 0.25em;\">User &amp; Permission Management</li><li style=\"margin-top: 0.25em;\">Objects: Forms, Subforms, Charts, Lookup, Images, HTML, Calc, File Upload etc. and other HTML5 types</li><li style=\"margin-top: 0.25em;\">Further customisation that can be done with Javascript and PHP.</li></ul>');
/*!40000 ALTER TABLE `trumbowyg_sample` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_browse` (
  `zzzzsys_browse_id` varchar(25) NOT NULL DEFAULT '',
  `sbr_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `sbr_title` varchar(100) DEFAULT NULL,
  `sbr_display` varchar(512) DEFAULT NULL,
  `sbr_align` char(1) DEFAULT NULL,
  `sbr_format` varchar(300) DEFAULT NULL,
  `sbr_order` int(11) DEFAULT NULL,
  `sbr_width` int(11) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_browse_id`),
  KEY `sbr_zzzsys_form_id` (`sbr_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_browse` DISABLE KEYS */;
INSERT INTO `zzzzsys_browse` VALUES ('5ec175123d2c612','5ec17511eab7236','First name','cus_firstname','l','',10,250);
INSERT INTO `zzzzsys_browse` VALUES ('5ec175123d5b927','5ec17511eab7236','Last name','cus_lastname','l','',20,250);
/*!40000 ALTER TABLE `zzzzsys_browse` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_event` (
  `zzzzsys_event_id` varchar(25) NOT NULL,
  `sev_zzzzsys_object_id` varchar(25) DEFAULT NULL,
  `sev_event` varchar(100) DEFAULT NULL,
  `sev_javascript` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_event_id`),
  KEY `sev_zzzsys_object_id` (`sev_zzzzsys_object_id`),
  KEY `sev_event` (`sev_event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_event` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_form` (
  `zzzzsys_form_id` varchar(25) NOT NULL,
  `sfo_type` varchar(300) DEFAULT NULL,
  `sfo_code` varchar(300) DEFAULT NULL,
  `sfo_description` varchar(300) DEFAULT NULL,
  `sfo_table` varchar(300) DEFAULT NULL,
  `sfo_primary_key` varchar(300) DEFAULT NULL,
  `sfo_browse_redirect_form_id` varchar(300) DEFAULT NULL,
  `sfo_browse_row_height` int(11) DEFAULT NULL,
  `sfo_browse_rows_per_page` int(11) DEFAULT NULL,
  `sfo_browse_sql` text,
  `sfo_javascript` longtext,
  PRIMARY KEY (`zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_form` DISABLE KEYS */;
INSERT INTO `zzzzsys_form` VALUES ('5ec17511eab7236','browseedit','trumbowyg_sampleBE','Trumbowyg Sample','trumbowyg_sample','trumbowyg_sample_id',NULL,NULL,NULL,'SELECT * FROM trumbowyg_demo','if (nuFormType() == \'edit\') {\n   \n    // init the trumbowyg plugin\n    $(\"div[id=\'cus_notes_tr\']\").trumbowyg({\n        btns: [\n            [\'viewHTML\'],\n            [\'undo\', \'redo\'],\n            [\'formatting\'],\n            [\'strong\', \'em\', \'del\'],\n            [\'justifyLeft\', \'justifyCenter\', \'justifyRight\', \'justifyFull\'],\n            [\'unorderedList\', \'orderedList\'],\n            [\'horizontalRule\'],\n            [\'removeformat\'],\n            [\'fullscreen\']\n        ],\n        semantic: false,\n        resetCss: true,\n        removeformatPasted: false\n    });\n\n    $(\'.trumbowyg-button-pane\').css(\'z-index\', \'1\');\n\n    // Get the html code of the nuBuilder object and assign it to the trumbowyg editor\n    var html = $(\'#cus_notes\').val();\n    $(\'#cus_notes_tr\').trumbowyg(\'html\', html);\n}\n\n\nfunction nuBeforeSave() {\n    \n    // Get the html code of the trumbowyg editor and assign it to the nuBuilder object\n    var html = $(\'#cus_notes_tr\').trumbowyg(\'html\');\n    $(\'#cus_notes\').val(html).change();\n   return true;\n   \n}');
/*!40000 ALTER TABLE `zzzzsys_form` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_object` (
  `zzzzsys_object_id` varchar(25) NOT NULL,
  `sob_all_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_all_table` varchar(300) DEFAULT NULL,
  `sob_all_type` varchar(300) DEFAULT NULL,
  `sob_all_id` varchar(300) DEFAULT NULL,
  `sob_all_label` varchar(1000) DEFAULT NULL,
  `sob_all_zzzzsys_tab_id` varchar(300) DEFAULT NULL,
  `sob_all_order` int(11) DEFAULT NULL,
  `sob_all_top` int(11) DEFAULT NULL,
  `sob_all_left` int(11) DEFAULT NULL,
  `sob_all_width` int(11) DEFAULT NULL,
  `sob_all_height` int(11) DEFAULT NULL,
  `sob_all_cloneable` varchar(300) DEFAULT NULL,
  `sob_all_align` varchar(10) DEFAULT NULL,
  `sob_all_validate` varchar(1) DEFAULT NULL,
  `sob_all_access` varchar(1) DEFAULT NULL,
  `sob_calc_formula` varchar(3000) DEFAULT NULL,
  `sob_calc_format` varchar(300) DEFAULT NULL,
  `sob_run_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_run_filter` varchar(300) DEFAULT NULL,
  `sob_run_method` varchar(1) DEFAULT NULL,
  `sob_run_id` varchar(300) DEFAULT NULL,
  `sob_display_sql` text,
  `sob_select_multiple` varchar(300) DEFAULT NULL,
  `sob_select_sql` text,
  `sob_lookup_code` varchar(300) DEFAULT NULL,
  `sob_lookup_description` varchar(300) DEFAULT NULL,
  `sob_lookup_description_width` varchar(300) DEFAULT NULL,
  `sob_lookup_autocomplete` varchar(300) DEFAULT NULL,
  `sob_lookup_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_lookup_javascript` text,
  `sob_lookup_php` varchar(25) DEFAULT NULL,
  `sob_lookup_table` varchar(500) DEFAULT NULL,
  `sob_subform_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_subform_foreign_key` varchar(300) DEFAULT NULL,
  `sob_subform_add` varchar(300) DEFAULT NULL,
  `sob_subform_delete` varchar(300) DEFAULT NULL,
  `sob_subform_type` varchar(300) DEFAULT NULL,
  `sob_subform_table` varchar(300) DEFAULT NULL,
  `sob_input_count` bigint(20) DEFAULT NULL,
  `sob_input_format` varchar(300) DEFAULT NULL,
  `sob_input_type` varchar(300) DEFAULT NULL,
  `sob_input_javascript` text,
  `sob_html_code` text,
  `sob_html_chart_type` varchar(1000) DEFAULT NULL,
  `sob_html_javascript` varchar(1000) DEFAULT NULL,
  `sob_html_title` varchar(1000) DEFAULT NULL,
  `sob_html_vertical_label` varchar(1000) DEFAULT NULL,
  `sob_html_horizontal_label` varchar(1000) DEFAULT NULL,
  `sob_image_zzzzsys_file_id` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_object_id`),
  KEY `sob_all_zzzzsys_form_id` (`sob_all_zzzzsys_form_id`),
  KEY `sob_all_zzzzsys_tab_id` (`sob_all_zzzzsys_tab_id`),
  KEY `sob_run_zzzzsys_form_id` (`sob_run_zzzzsys_form_id`),
  KEY `sob_lookup_zzzzsys_form_id` (`sob_lookup_zzzzsys_form_id`),
  KEY `sob_subform_zzzzsys_form_id` (`sob_subform_zzzzsys_form_id`),
  KEY `sob_image_zzzzsys_file_id` (`sob_image_zzzzsys_file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_object` DISABLE KEYS */;
INSERT INTO `zzzzsys_object` VALUES ('5ec17512090cc92','5ec17511eab7236','customer','input','cus_firstname','First name','5ec17511eb8341a',10,34,86,300,20,'1','left','0','0','','','','','','','','','','','','','','','','','','','','','','','',0,'','text','','','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ec1751209985ae','5ec17511eab7236','customer','input','cus_lastname','Last name','5ec17511eb8341a',20,64,86,300,20,'1','left','0','0','','','','','','','','','','','','','','','','','','','','','','','',0,'','text','','','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ec175120a31136','5ec17511eab7236','customer','html','cus_notes_html','Notes','5ec17511eb8341a',40,94,86,800,443,'1','right','0','0','','','','','','','SELECT COUNT(*) FROM zzzzsys_debug','','','','','','','','','','','','','','','','',0,'N|$ 1,000.00','','','<style>\nli {\n    display: list-item;\n}\n</style>\n\n<div id=\"cus_notes_tr\" placeholder=\"Placeholder here...\" style=\"background:white\"></div>','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ec17989068e9be','5ec17511eab7236','customer','textarea','cus_notes','Notes','5ec17511eb8341a',30,64,1019,300,100,'1','left','0','2','','','','','','','','','','','','',NULL,'','',NULL,'','','','','','','',0,'','text','','','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ec175123dd0a46','nuuserhome','customer','run','run_trumbowyg_sample','Trumbowyg Sample','nufastforms',20,361,309,150,34,'0','center','0','0',NULL,NULL,'5ec17511eab7236',NULL,'b','5ec179d39fc1fa4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `zzzzsys_object` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_php` (
  `zzzzsys_php_id` varchar(25) NOT NULL,
  `sph_code` varchar(300) DEFAULT NULL,
  `sph_description` varchar(300) DEFAULT NULL,
  `sph_group` varchar(100) DEFAULT NULL,
  `sph_php` longtext,
  `sph_run` varchar(20) DEFAULT NULL,
  `sph_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `sph_system` varchar(1) DEFAULT NULL,
  `sph_hide` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_php_id`),
  KEY `sph_zzzzsys_form_id` (`sph_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_php` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_php` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_select` (
  `zzzzsys_select_id` varchar(25) CHARACTER SET utf8 NOT NULL,
  `sse_description` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `sse_json` mediumtext CHARACTER SET utf8,
  `sse_sql` mediumtext CHARACTER SET utf8,
  `sse_edit` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `sse_system` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_select_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_select` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_select` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_select_clause` (
  `zzzzsys_select_clause_id` varchar(25) NOT NULL,
  `ssc_zzzzsys_select_id` varchar(25) DEFAULT NULL,
  `ssc_type` varchar(300) DEFAULT NULL,
  `ssc_field` varchar(500) DEFAULT NULL,
  `ssc_clause` varchar(500) DEFAULT NULL,
  `ssc_sort` varchar(10) DEFAULT NULL,
  `ssc_order` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_select_clause_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_select_clause` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_select_clause` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_tab` (
  `zzzzsys_tab_id` varchar(25) NOT NULL,
  `syt_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `syt_title` varchar(250) DEFAULT NULL,
  `syt_order` int(11) DEFAULT NULL,
  `syt_help` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_tab_id`),
  KEY `syt_zzzzsys_form_id` (`syt_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_tab` DISABLE KEYS */;
INSERT INTO `zzzzsys_tab` VALUES ('5ec17511eb8341a','5ec17511eab7236','Main',10,NULL);
/*!40000 ALTER TABLE `zzzzsys_tab` ENABLE KEYS */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

