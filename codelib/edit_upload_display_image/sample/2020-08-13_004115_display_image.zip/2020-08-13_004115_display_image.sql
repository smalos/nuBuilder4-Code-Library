/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `display_image` (
  `display_image_id` varchar(25) NOT NULL,
  `dsp_image_json` longtext NOT NULL,
  PRIMARY KEY (`display_image_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `display_image` DISABLE KEYS */;
INSERT INTO `display_image` VALUES ('5f19e0b7b93a250','{\"file\":\"ZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFLc0FBQUErQ0FZQUFBQlVRK3ZwQUFBQUNYQklXWE1BQUJZbEFBQVdKUUZKVWlUd0FBQUFCM1JKVFVVSDRRa2FGaklXSW5lSjd3QUFEaU5KUkVGVWVOcnRuWHQwVmRXZHh6Ky9jMjRTREkvY1JHUUVIL1d4ckFwVDYyUFZCMUt4dGVPcWRvb1FHclNEdFlJSWdWbXVsclpNeHlrelZNZDIydFdwenVCQURRWE1XTmU0SkNhcHNUaUY2Um9meXlxMkkzMkF1S3d3Z3c5SUVEQTNQQkx1NDV6Zi9ISE92ZmZrNXB4N0UvSzg1SHl6ZHU2OVorK3p6MzU4OTIvLzltOC9qcWdxSVVJVUE0eXdDRUtFWkEwUklpUnJpSkNzSVVLTWNFUUNmZXJsUmt4bVlISm1qMUEyWUNGWVlMdWZKQkVTUUJ4SUlDUVFrb0RTYVJqczRoaFBzMXFQcEtPNHJWbm1Zek94VzhzUnVrVDR1U3EzV2pERlVNb1JmbTladlBaY2plNERxRzZXMHkyYk8zT1Rxd1p2dE16UlYyWTF5YWRFbWQ0am84S214bXB0bFliMmN6SGxpUUxsWWlQU2h0cnZnL0VPWlRUcUZ5cmFCNk1DcExIOVI0aDh5dGZUaXQ2RTJiRUE5RTUvZjN1WjFsVHRLdmlNaG8rbVlocHJnMnBhcTZQMXhVdldmNWUvb1pUWm1DaW1LMys5TXRoeTcweUJZVGtrVlVXd2tReVJEY1Q5UTJFR1k2bVdsYktJaHh6U2lYS2pDaGQwSTV5aU5ud0pNQVZRQWVBNncyVHBiVTN5WXBuRjkxTXdRVXhtNVNiWlZMcUFWeFF1RXVucG4xUitCYlJpMk9WZ3ppeFlNcXFBQUFweGVWU2FZMCtUc3I2ak5hZnZHK0MrN1RLVWZPazVId0w4amNqNFhqM0RaRUpnSFBCQzhhb0JUOGpWbERLYkVwUVNvQlIxdjJ2bWUvWWFSRkJLWGZLbXlaMzk3V25lVExSdHZwMlhINExrM09YRmpWM0NqY05UVERvRzVhdVk1Z3ZTY21oSzJDR1BGTEthWEVQRUpWMEpTZ1F5cEhSK3AwbnFYSE5KS3FiN1BRSVlLQ2FLUVRjanJpaFg4WUJFVGpheHBuREpNSmZYUmFRaXpTRnRSZ3BaRFNaaWRDZWlLMDNKa0RGTjVyVDBkTDlMbXFDRzUzbzN0bElLUkFOMUswVWpjS2R0ODQrKzhnM0tCcjFFUko0Q1hzNFQ0bXBwT0ZJMWNFSmJPb0dqQVM1RVhwMjFCTWtRemNnUWxveVVORnk5RkJSRlhISm1QMDBQVWRPNnJ1MkpQNDRFMWh0ME5GWnI2N3dHMGZod2xZaHRQNGxkdVFVenRoczR6NytKVzljQ3p3OElWNnVqYy9LMm5hYVFwUGtIV09KS3g2elRqSlJVbkpHSG5ia3VwTnl4aU5lbDViYjBQVkh4TXBUVThCV0sxbUJKTTYrZ0FXUVZZNHBEcFBZZmdwemhJNTBQNkp5Sys1MHdzZThDNS9xVThSR2RFLzI2Tk1XK0NVenpmYzZPNkNJKzBjc09vZVhRZUZLUmUwQ3ZCVGtIbFE0TWJjWG1aZFI0dHk5R1NtazVOQVVyY2pzMjV5Rk1BYzVFaUtPMEFXM0FUcXprTTFwenhyRnU5elczejBmbHBvQSsvRUVzbllISVRGVE9RblE4OEM3SWk1eFc4VE85aGZqSmtqWDdLVDZrRTFlSzVpb1Q0aE5Ic1VMcHhhSUorUkowdDJpNGxvUjNnUHZkZUc1RHVOd24vZ1BBMXhHOUdaV2JmYU9meXIyOUl0ZlBPNjdDam13RnFqSUZMNG9yVmhZaXhIdE4wcFQ1TUVUbUFwRnVkWmhiR21iSmFtbUsxV05GdjZVMUpGeVY1aHBnUVlBeGNEWWlsWm0wT1pnQk9wK3UyRXBwa3M5cWRjWC85azFuOVNaTVBYWlY3ZWFrVzlkdUIyUW94T0NyMkM4U3dkYm5IYUlHb3FDdUx3MEh4NUdLL0FMa2R2TFozN01ZRDl4SHBLTmVIdWlWM0s3TTQvY3gwSmErRDdEd2tOR3htWUx0R3Y0ZEp4bnkycDd2ZnM0T0NUem9PQno3QkRDcC93cGg1QitBSy9yZUErbVh1U3cyZXdCeU1rMmFZaC9yRzFsVEdWTGlNZktuWjZ5OHY4a1FXblBDcGovMVZDWHI4STMvZXRhZ1RNd2pMOTlDNVhiZ3VjSlpNbVlFRFNGQTdrWDFuL1BjZkczaExrQzNJbndOcEMzUDZIWnkzOGhxWjV3emNFcGxQaDJYY0srbHAxblQvaGFvN2M1aVdSNUNGeTlaeS9PWW05NHFqaXpZVCtyY2lrMElQODdMb3djd1FDOFA4SDVWcXl2V1UxNjUwbVdBWDNsY1hyZ3htQ3QxVG5RMW9rK2ZkTHYwbGF4WkFqcnoreW1FcE92UzF4eVhEZWNsdEkyZ2J0aGkxQU1iRHA0SjNCTGcvUVoyeGUrS0l5UFM1UkRGenQ4VHpNUUFUZ3RRQ1k4RHVLUDFaRUFNcFlYSm11cDBFM1Zzd0V4WGRoSXhzbU4remRoVnhaV1JYbjAyVGRRRXFFUHd0TFROcWhORngxUlppMWx5anI4K0w5dXdqTHUxcGloelZ2U0krRWxXQlJGRnNaR01uZFZycXJKYzBycWsxTFRrVGJuU051MktFMzVLL241VXY4M082SC9vcW01MmtCRERTdGE0SXpsZC9SUEp6bEIxTjJPbGRWU3YycEJ3cFd1eVNLVnFNRjRIUG1KcTBWdVBpeG85dTdvRTJmV29jZEFFb25GRVQ3Z3VrWFVrTXBJVWQvMnF1SnBOTVZmcVFaOXJjeERaakJsN1dSbzZ6ZzlwTTFJa2F5S2psMmJuK3IxVHFHUWxhMmJ0YXNwRDJtU1JTeC9WdXpHTnQ3SFpDVG9teDNjNkpzOUwvZDRyOU83elRvd0toZ2dYdTFQRzRLeS82MmY1SnRjZ2tRWmZ2MlBKM1gwbHEyVE1WdWtGS2VJWllLVUhXWDVrUFVXNmZwMWRzVWVhWXY4SitDd3kwVXVZRUwwRHFCOGxBdTBpWU5XQWxXMzF4RmFnZFdBa2E5TFZPM05YVHVXMk55dEh1ZzZ6UGRWU3hnSVl5dGdCa3UzSDhraWJ5d2t4QXRRQW0rTUlqcTAwU1hZUlMzYzFRRTVxS2xWUnloeTczWUQzVnNKTnN4dWxIT0hxSVNpM2FFaWRFVUJXUTNoVFliYUh2Rmw1MG4vczVidmEyWjhJVXVQWVg5S0ZSYytsM2FlcDhObXdTZ2NjT3hGZGsxOEl5Zjdoa2F5SDJheFYzQ0hDaFFNdS9VeFc5emVPNTIvUitHMk4wb0J3Ujhpam9WRGcyYXZWbFk4QlNIUHNWNmp2Q3E3ZkF5MURUOVk2VFJwL0swdHNXQzdDcDRFSi9WY24yVzNBR2g3UzE3S0RidDVTaU9WMDVjY0FyR01rakRLMjkyekF2QWZRTXBmMVgyeGloeWpUUlppdU1FR2h6WUJmbyt5MzRZYmNlMDF6Y05TUFVVYmM2ZmhQeXc3SjBOcC8zZUlQdE1NQXgxeXhRc1l5cmg4cXdIN2lVcWM5NXBTZm5hc1BCOTN5aTcvU2RtQkZIdFZYcVdZYnNFMlFSMm9hTURiVnFMZkFuZ3VaTlJvR1dMbjRrUjRmMlkxZGxYQ3VmbFFnUEQ0b0dHUHl0SkJEWWZHRVpCMFJrTTBkbFFRdkVRVFZOM3BOZEpHeVljdUl1ak53dGpFbWI3aVhzRUg4WitURVdkY3JEWlFTUElPVkdCbHF3T2hydmc4VDEvUEp0MGJUam13dkVNczUwaHhianNweDBFc0htWkY1aUNMenBUbjJOZ1pmelJ2REtteHA0bmZBZFQ1eFRKZkdqbm1ZZW1rZ1gxVC9FSkxWQjh0azR5ejdKSXp5SmllYTF1aXl3Z3QvVlM0dUVPSlJyUm4vdHZ2OUVINjdXeDFWNGVFaDJTWmhwcmFUaXZqWm5RR21vVFQya3ZTditwTlZ4eUFVV04xdmJBdko2aWZVME84QmY5N25ycDJ5bDhnM2hkcTdDdDFDVmVVM1BKSCtFdTNuak5tWEc5OC9ONTdzY1RoYUVxeldUVXNMcDJqV3hLUFMyTDRSa1h2N3g0VFVBNlFpbndNKzJiZUMxVTNzaURZek55VHJTTUdicUR6SXp1Z3ozUlpmSDR3K3hNVFlWSnlURC8zd29hdm5CVzVEbmhaUG5ET0Rzcy9rWHUvQ092cEVyMXR3NVZMTVdCeW9EYTVUMlFaNkRRRXprVHByNGxGcCt1Z3Z3WGdFWndHUFdlQ3B4MEdlWUV4MCtWQXRTRC9GeUtyYlFaN3g4MGxpT1JNUVJ1bEJzRmNVanNydXhEWjJZN0NiSFJWN2RSVjJydlRReFNTRjZEeWFZcDlHOVU1RUxuVExkQzhpT3pDVGRWaVJPU0NUZk9NSHp2YWMrTkM5WXNSa0Y4bzArNWVZUnNEWnNJbjN3RGxCQnFMM1NjdWhmeUpwTGtEa1Vwd2REMTBvZjBKbzFPcUtGNlN4WXg1R3p1a3dsdlZxSmtuVlZSOEFOZEwwMGRtSWVRZTJ1aWV5eUdSRVQ2RFNCdG9HOGlaZDFpYWRYM1drZTZPUlp6R2RpWnNlS0NrNTBPK0JiN0c5cmFWV051eklvd2JVUDZiM0xPaHRYRXRrWGJsQjZTU3dLa0VyRlV6RlBGeUNmZmdNUHRpM1NsZWxmTzZaREtXKzI1L0hNblkzUUNmSHpqZXdUbGUwSEl3UFN4aXpaN1hPUCtLSjQwSW9kVWJacE9wQnJ2U0p6bExNSzdMcVQ2cjlwN3JvZzl4QWQ4blB4cFlSbjFRQ1ZTbk1Tb2ZvVnJ1RkhZdVFPdEFyUGIxSU1PclVnTCtXdGVOc3lwYUIzaXFZMXl0V0pLMkFPdjl0VWtBclp4K3RsUTB2SzdvWjdQVjF1ampwK0J2THdmS1Z6SjBjZVFXNEVpaTNQVXZWRXB4STFNcUdMWXExdkU0WDd4SE1lckJtZUovck4zUVNyRDltQjRqRzQ4QkNnSHRrNC9nSTNDZm9yZVZ3SFlqaEhEMW11OFFXQkJNTDA2NlZEYjhWWkt0SjVGLy9UZTg2WE55R21sR0VKYkx1UW91eTF4VitxTWpNQW8xMVBQQUZRZGFDK1Q5TFpGMXZ6b2FkZ2Y5NUE2WEFGd1h6dDB0a1hYay9yU0VYUk5EWHhSbG9YbCtnRGczZ0drWC9Qa1Z5K3pKWmYxa29XWXNHNWdwZ2FwQUtBWklBWGR6VGtzQmxZTndQK2UyVndCOFV0b2t6NERyZHg3L1N4TGpLUnVzVU5ydXgxNHIvamxwYjBlOTRmdTl3TEdMNkxZRUEyNjA4RHBvQzN3UGR6cldSRmNCWFFySVdCM3lQWTFSNHQ4N1ZkV3RsNHcyZ1BsTFUrSHd2aGdCTDYzVGhhMHRsL1dGRi9zNHZSQXJUV0tjTG52VG80TGZpVDFhclRoZjlvR2RhNVRNQjl0di9lMHdYTG5Uam5BbDgzQ2ZNRGFGa0hUbTRybFkyclBHcDRHZnFkT0VMRWpEZkwzaVBoQXc2eDBvTGxwVWljVWRuNU1UZzdaclVnS2xUeWNtRCtEWEtTRWpXa1lPTFhaZERSdjBUUmZSV2toRGhBQ3RFa2VOVW14VFlaQkw1V3U3Vm81aEhoMVlDbEc2MHNiYjYrWTJoZEpCT0lOUXphMlc5dTIxSXpnckpPdUlobld2MDdyYmhUc1ZQOUs1OXdMNGhmbXdVNUw1UURRZ1JJcFNzSVFZUWUwcVFHd0FTNkYrQVZ2UWNhQnJIUTdLR0dBa3FVUEpSWGJnZm9GYldmeE9reDB1SkZOMFBiQWpWZ0JBaFFyS2UraEl4d0tOa3NmejA0Mkg1akY0MTRBUGdiSi9yazViSXV2SjJLbE5WeU9TQTZjeEJXckZrdHdhdHZESXduMTBxRzdjcWVoQjB6Mk82NkNuWHluQmV6OUQ2WjkrUWh0TlN0TmxRSHZUV2swTWhXWXNFaWpTSi8ydHdvb0o1b0lvak5nRW4wQWpTTWpocE1uWUZIOEdvbHlqcE40SExPOEJUenR0YzlYcWZ3SldkSFBrUXlnUHpZQ0RQaG1wQWtXQUs3LzlZMEpYZ3V3MWpYRkFsSzlTZHdGZzVHR2t5aWY4RUFsYlgrMkF5Ny84THpubXAyc2M4UEhLWThRK0ZrblVvTlR4a2kyTHZDcWlRMytTN2Q1V3Vzb0h2TFpUSDE1V2hOK09ZZU01U3BCSm5uMVNKUXJ1QnRpc2NBSGxKc2JiVTZlSTlubWorQ0xySm4zZ2E2MnQrMXVyUzlublNjRUVsUjI4QyswcEJvdXJzM3EwUTFDTk1wTldUaHdmdmxmVjFCdko1Z2M4Qms0RXFoU3B4U053T3hBUmFGZmx2SmZWZmRicjR2V0lYTmtXM3JTVkVhQTBJRVNJa2E0Z1FJVmxEaEdRTkVXS2s0djhCd2cxQWNlSk1iSU1BQUFBQVNVVk9SSzVDWUlJPQ==\",\"name\":\"logo.png\",\"size\":3716,\"type\":\"image/png\"}');
/*!40000 ALTER TABLE `display_image` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_browse` (
  `zzzzsys_browse_id` varchar(25) NOT NULL DEFAULT '',
  `sbr_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `sbr_title` varchar(100) DEFAULT NULL,
  `sbr_display` varchar(512) DEFAULT NULL,
  `sbr_align` char(1) DEFAULT NULL,
  `sbr_format` varchar(300) DEFAULT NULL,
  `sbr_order` int(11) DEFAULT NULL,
  `sbr_width` int(11) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_browse_id`),
  KEY `sbr_zzzsys_form_id` (`sbr_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_browse` DISABLE KEYS */;
INSERT INTO `zzzzsys_browse` VALUES ('5f2a082fb40ff94','5ea8b9743b41051',' ','dsp_image_json','l',NULL,10,300);
/*!40000 ALTER TABLE `zzzzsys_browse` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_event` (
  `zzzzsys_event_id` varchar(25) NOT NULL,
  `sev_zzzzsys_object_id` varchar(25) DEFAULT NULL,
  `sev_event` varchar(100) DEFAULT NULL,
  `sev_javascript` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_event_id`),
  KEY `sev_zzzsys_object_id` (`sev_zzzzsys_object_id`),
  KEY `sev_event` (`sev_event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_event` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_form` (
  `zzzzsys_form_id` varchar(25) NOT NULL,
  `sfo_type` varchar(300) DEFAULT NULL,
  `sfo_code` varchar(300) DEFAULT NULL,
  `sfo_description` varchar(300) DEFAULT NULL,
  `sfo_table` varchar(300) DEFAULT NULL,
  `sfo_primary_key` varchar(300) DEFAULT NULL,
  `sfo_browse_redirect_form_id` varchar(300) DEFAULT NULL,
  `sfo_browse_row_height` int(11) DEFAULT NULL,
  `sfo_browse_rows_per_page` int(11) DEFAULT NULL,
  `sfo_browse_sql` text,
  `sfo_javascript` longtext,
  PRIMARY KEY (`zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_form` DISABLE KEYS */;
INSERT INTO `zzzzsys_form` VALUES ('5ea8b9743b41051','browseedit','display_image','Display Image Demo','display_image','display_image_id',NULL,200,5,'SELECT * FROM display_image\n\n','function getImageMeta(url, callback) {\n    var img = new Image();\n    img.src = url;\n    img.onload = function () {\n        callback(this.width, this.height);\n    }\n}\n\n\nfunction embedImage(json, d, w, h) {\n\n    if (json === \'\') {\n        return;\n    }\n\n    var ob = JSON.parse(json);\n    var ty = ob.type;\n    var ur = atob(ob.file);\n\n    getImageMeta(ur, function (width, height) {\n        var x = document.createElement(\"EMBED\");\n\n        x.setAttribute(\"type\", ty);\n        x.setAttribute(\"src\", ur);\n\n        if (w !== undefined) {\n            width = w;\n        }\n        if (h !== undefined) {\n            height = h;\n        }\n\n        x.setAttribute(\"width\", width);\n        x.setAttribute(\"height\", height);\n\n        $(\'#\' + d).html(\'\');\n        document.getElementById(d).appendChild(x);\n\n    });\n\n}\n\n\nif (nuFormType() == \'edit\') {\n    showEditImage();\n} else {\n    showBrowseImages();\n}\n\n\nfunction nuBeforeSave() {\n\n    var f = $(\'#dsp_image_file\').val();\n\n    if (f !== \'\') {\n\n        $(\'#dsp_image_json\')\n            .val(f)\n            .change();\n\n    }\n\n    return true;\n\n}\n\n\nfunction showEditImage() {\n    var json = $(\'#dsp_image_json\').val();\n    embedImage(json, \'dsp_view_image\');\n}\n\n\nfunction showBrowseImages() {\n\n    $(\'[data-nu-column=\"0\"]\').each(function (index) {\n        var h = $(this).html();\n        if (h !== \'\' && h !== undefined) {\n            nuEmbedObject(h, $(this).attr(\'id\'), 140, 140);\n        }\n    });\n\n}');
/*!40000 ALTER TABLE `zzzzsys_form` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_object` (
  `zzzzsys_object_id` varchar(25) NOT NULL,
  `sob_all_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_all_table` varchar(300) DEFAULT NULL,
  `sob_all_type` varchar(300) DEFAULT NULL,
  `sob_all_id` varchar(300) DEFAULT NULL,
  `sob_all_label` varchar(1000) DEFAULT NULL,
  `sob_all_zzzzsys_tab_id` varchar(300) DEFAULT NULL,
  `sob_all_order` int(11) DEFAULT NULL,
  `sob_all_top` int(11) DEFAULT NULL,
  `sob_all_left` int(11) DEFAULT NULL,
  `sob_all_width` int(11) DEFAULT NULL,
  `sob_all_height` int(11) DEFAULT NULL,
  `sob_all_cloneable` varchar(300) DEFAULT NULL,
  `sob_all_align` varchar(10) DEFAULT NULL,
  `sob_all_validate` varchar(1) DEFAULT NULL,
  `sob_all_access` varchar(1) DEFAULT NULL,
  `sob_calc_formula` varchar(3000) DEFAULT NULL,
  `sob_calc_format` varchar(300) DEFAULT NULL,
  `sob_run_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_run_filter` varchar(300) DEFAULT NULL,
  `sob_run_method` varchar(1) DEFAULT NULL,
  `sob_run_id` varchar(300) DEFAULT NULL,
  `sob_display_sql` text,
  `sob_select_multiple` varchar(300) DEFAULT NULL,
  `sob_select_sql` text,
  `sob_lookup_code` varchar(300) DEFAULT NULL,
  `sob_lookup_description` varchar(300) DEFAULT NULL,
  `sob_lookup_description_width` varchar(300) DEFAULT NULL,
  `sob_lookup_autocomplete` varchar(300) DEFAULT NULL,
  `sob_lookup_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_lookup_javascript` text,
  `sob_lookup_php` varchar(25) DEFAULT NULL,
  `sob_lookup_table` varchar(500) DEFAULT NULL,
  `sob_subform_zzzzsys_form_id` varchar(300) DEFAULT NULL,
  `sob_subform_foreign_key` varchar(300) DEFAULT NULL,
  `sob_subform_add` varchar(300) DEFAULT NULL,
  `sob_subform_delete` varchar(300) DEFAULT NULL,
  `sob_subform_type` varchar(300) DEFAULT NULL,
  `sob_subform_table` varchar(300) DEFAULT NULL,
  `sob_input_count` bigint(20) DEFAULT NULL,
  `sob_input_format` varchar(300) DEFAULT NULL,
  `sob_input_type` varchar(300) DEFAULT NULL,
  `sob_input_javascript` text,
  `sob_html_code` text,
  `sob_html_chart_type` varchar(1000) DEFAULT NULL,
  `sob_html_javascript` varchar(1000) DEFAULT NULL,
  `sob_html_title` varchar(1000) DEFAULT NULL,
  `sob_html_vertical_label` varchar(1000) DEFAULT NULL,
  `sob_html_horizontal_label` varchar(1000) DEFAULT NULL,
  `sob_image_zzzzsys_file_id` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_object_id`),
  KEY `sob_all_zzzzsys_form_id` (`sob_all_zzzzsys_form_id`),
  KEY `sob_all_zzzzsys_tab_id` (`sob_all_zzzzsys_tab_id`),
  KEY `sob_run_zzzzsys_form_id` (`sob_run_zzzzsys_form_id`),
  KEY `sob_lookup_zzzzsys_form_id` (`sob_lookup_zzzzsys_form_id`),
  KEY `sob_subform_zzzzsys_form_id` (`sob_subform_zzzzsys_form_id`),
  KEY `sob_image_zzzzsys_file_id` (`sob_image_zzzzsys_file_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_object` DISABLE KEYS */;
INSERT INTO `zzzzsys_object` VALUES ('5ea8b974490caf0','5ea8b9743b41051','display_image','textarea','dsp_image_json','Image JSON','5ea8b9743b5f721',10,114,118,300,19,'1','right','1','2','','','','','','','SELECT COUNT(*) FROM zzzzsys_debug','','','','','','','','','','','','','','','','',89,'N|$ 1,000.00','file','','','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ecb158ce2f8d94','5ea8b9743b41051','display_image','input','dsp_image_file','File','5ea8b9743b5f721',20,59,118,300,21,'1','right','0','0','','','','','','','SELECT COUNT(*) FROM zzzzsys_debug','','','','','',NULL,'','',NULL,'','','','','','','',89,'','file','','','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ec1c698bc025c7','5ea8b9743b41051','display_image','html','dsp_view_image','Image','5ea8b9743b5f721',30,154,118,20,20,'1','right','0','0','','','','','','','SELECT COUNT(*) FROM zzzzsys_debug','','','','','',NULL,'','',NULL,'','','','','','','',89,'','file','',' ','','','','','','');
INSERT INTO `zzzzsys_object` VALUES ('5ea8b974553c6ca','nuuserhome','display_image','run','run_display_image','Upload & Display Image Demo','nufastforms',20,312,309,150,34,'0','center','0','0',NULL,NULL,'5ea8b9743b41051',NULL,'b','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `zzzzsys_object` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_php` (
  `zzzzsys_php_id` varchar(25) NOT NULL,
  `sph_code` varchar(300) DEFAULT NULL,
  `sph_description` varchar(300) DEFAULT NULL,
  `sph_group` varchar(100) DEFAULT NULL,
  `sph_php` longtext,
  `sph_run` varchar(20) DEFAULT NULL,
  `sph_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `sph_system` varchar(1) DEFAULT NULL,
  `sph_hide` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_php_id`),
  KEY `sph_zzzzsys_form_id` (`sph_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_php` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_php` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_select` (
  `zzzzsys_select_id` varchar(25) CHARACTER SET utf8 NOT NULL,
  `sse_description` varchar(300) CHARACTER SET utf8 DEFAULT NULL,
  `sse_json` mediumtext CHARACTER SET utf8,
  `sse_sql` mediumtext CHARACTER SET utf8,
  `sse_edit` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  `sse_system` varchar(1) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_select_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_select` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_select` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_select_clause` (
  `zzzzsys_select_clause_id` varchar(25) NOT NULL,
  `ssc_zzzzsys_select_id` varchar(25) DEFAULT NULL,
  `ssc_type` varchar(300) DEFAULT NULL,
  `ssc_field` varchar(500) DEFAULT NULL,
  `ssc_clause` varchar(500) DEFAULT NULL,
  `ssc_sort` varchar(10) DEFAULT NULL,
  `ssc_order` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_select_clause_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_select_clause` DISABLE KEYS */;
/*!40000 ALTER TABLE `zzzzsys_select_clause` ENABLE KEYS */;

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `zzzzsys_tab` (
  `zzzzsys_tab_id` varchar(25) NOT NULL,
  `syt_zzzzsys_form_id` varchar(25) DEFAULT NULL,
  `syt_title` varchar(250) DEFAULT NULL,
  `syt_order` int(11) DEFAULT NULL,
  `syt_help` varchar(3000) DEFAULT NULL,
  PRIMARY KEY (`zzzzsys_tab_id`),
  KEY `syt_zzzzsys_form_id` (`syt_zzzzsys_form_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `zzzzsys_tab` DISABLE KEYS */;
INSERT INTO `zzzzsys_tab` VALUES ('5ea8b9743b5f721','5ea8b9743b41051','Main',10,NULL);
/*!40000 ALTER TABLE `zzzzsys_tab` ENABLE KEYS */;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

